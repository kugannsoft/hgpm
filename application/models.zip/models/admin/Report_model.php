<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        
    }

    public function loadroot() {
        $this->db->select();
        $this->db->from('location');
        return $this->db->get()->result();
    }

    public function loadproduct() {
        $this->db->select('ProductCode,Prd_Description');
        $this->db->from('product');
        return $this->db->get()->result();
    }

    public function loadSerialProduct() {
        $this->db->select('product.ProductCode,product.Prd_Description');
        $this->db->from('product');
        $this->db->join('productcondition', 'productcondition.ProductCode = product.ProductCode', 'INNER');
        $this->db->where('productcondition.IsSerial', 1);
        return $this->db->get()->result();
    }

    public function gensalesreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL,$invtype,$salesperson= NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('customer.CusCode,customer.MobileNo,DATE(salesinvoicehed.SalesDate) As InvDate,(salesinvoicehed.SalesDisAmount) AS DisAmount,salesinvoicehed.SalesInvNo,
                                (salesinvoicehed.SalesCashAmount) AS CashAmount,
                                (salesinvoicehed.SalesCCardAmount) AS CCardAmount,
                                (salesinvoicehed.SalesCreditAmount) AS CreditAmount,
                                (salesinvoicehed.SalesGiftVAmount) AS GiftVAmount,
                                (salesinvoicehed.SalesLoyaltyAmount) AS LoyaltyAmount,
                                (salesinvoicehed.SalesStarPoints) AS StarPoints,
                                (salesinvoicehed.SalesChequeAmount) As ChequeAmount,
                                (salesinvoicehed.SalesInvAmount) AS InvAmount,
                                (salesinvoicehed.SalesVatAmount) AS VatAmount,
                                (salesinvoicehed.SalesNbtAmount) AS NbtAmount,
                                (salesinvoicehed.SalesNetAmount) AS NetAmount,
                                (salesinvoicehed.SalesAdvancePayment) AS AdvanceAmount,
                                (salesinvoicehed.SalesCustomerPayment) AS CustomerPayment,
                                (salesinvoicehed.SalesCostAmount) AS CostAmount,
                                (salesinvoicehed.SalesReturnAmount) AS ReturnAmount,customer.CusName,
                                customer.RespectSign,creditinvoicedetails.SettledAmount');
            $this->db->from('salesinvoicehed');
            $this->db->join('customer', 'customer.CusCode = salesinvoicehed.SalesCustomer', 'INNER');
            // $this->db->join('salesinvoicedtl', 'salesinvoicedtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            $this->db->join('creditinvoicedetails', 'creditinvoicedetails.InvoiceNo = salesinvoicehed.SalesInvNo', 'left');
            $this->db->where('DATE(salesinvoicehed.SalesDate) <=', $enddate);
            $this->db->where('DATE(salesinvoicehed.SalesDate) >=', $startdate);
            $this->db->where_in('salesinvoicehed.SalesLocation', $locationAr);
            $this->db->where('salesinvoicehed.InvIsCancel', 0);
            if (isset($invtype) && $invtype != '') {
                $this->db->where('salesinvoicehed.SalesInvType', $invtype);
            }
            
            if (isset($salesperson) && $salesperson != '') {
                $this->db->where('salesinvoicehed.SalesPerson', $salesperson);
            }

            // $this->db->group_by('DATE(SalesInvNo)');
             $this->db->order_by('salesinvoicehed.SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('customer.MobileNo,customer.CusCode,DATE(salesinvoicehed.SalesDate) As InvDate,(salesinvoicehed.SalesDisAmount) AS DisAmount,salesinvoicehed.SalesInvNo,
                                (salesinvoicehed.SalesCashAmount) AS CashAmount,
                                (salesinvoicehed.SalesCCardAmount) AS CCardAmount,
                                (salesinvoicehed.SalesCreditAmount) AS CreditAmount,
                                (salesinvoicehed.SalesGiftVAmount) AS GiftVAmount,
                                (salesinvoicehed.SalesLoyaltyAmount) AS LoyaltyAmount,
                                (salesinvoicehed.SalesStarPoints) AS StarPoints,
                                (salesinvoicehed.SalesChequeAmount) As ChequeAmount,
                                (salesinvoicehed.SalesInvAmount) AS InvAmount,
                                (salesinvoicehed.SalesVatAmount) AS VatAmount,
                                (salesinvoicehed.SalesNbtAmount) AS NbtAmount,
                                (salesinvoicehed.SalesNetAmount) AS NetAmount,
                                (salesinvoicehed.SalesAdvancePayment) AS AdvanceAmount,
                                (salesinvoicehed.SalesCustomerPayment) AS CustomerPayment,
                                (salesinvoicehed.SalesCostAmount) AS CostAmount,
                                 (salesinvoicehed.SalesBankAmount) AS BankAmount,
                                (salesinvoicehed.SalesReturnAmount) AS ReturnAmount,customer.CusName,
                                customer.RespectSign,creditinvoicedetails.SettledAmount');
            $this->db->from('salesinvoicehed');
            $this->db->join('customer', 'customer.CusCode = salesinvoicehed.SalesCustomer', 'INNER');
            // $this->db->join('salesinvoicedtl', 'salesinvoicedtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            $this->db->join('creditinvoicedetails', 'creditinvoicedetails.InvoiceNo = salesinvoicehed.SalesInvNo', 'left');
            $this->db->where('DATE(salesinvoicehed.SalesDate) <=', $enddate);
            $this->db->where('DATE(salesinvoicehed.SalesDate) >=', $startdate);
            $this->db->where('salesinvoicehed.InvIsCancel', 0);
            if (isset($invtype) && $invtype != '') {
                $this->db->where('salesinvoicehed.SalesInvType', $invtype);
            }

            if (isset($salesperson) && $salesperson != '') {
                $this->db->where('salesinvoicehed.SalesPerson', $salesperson);
            }
            
            
             $this->db->order_by('salesinvoicehed.SalesDate', 'DESC');
            // $this->db->group_by('salesinvoicehed.SalesInvNo');
            // $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }
    
    public function genreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(InvDate) As InvDate,SUM(InvDisAmount) AS DisAmount,
                                SUM(InvCashAmount) AS CashAmount,
                                SUM(InvCCardAmount) AS CCardAmount,
                                SUM(InvCreditAmount) AS CreditAmount,
                                SUM(InvGiftVAmount) AS GiftVAmount,
                                SUM(InvLoyaltyAmount) AS LoyaltyAmount,
                                SUM(InvStarPoints) AS StarPoints,
                                SUM(InvChequeAmount) As ChequeAmount,
                                SUM(InvAmount) AS InvAmount,
                                SUM(InvVatAmount) AS VatAmount,
                                SUM(InvNbtAmount) AS NbtAmount,
                                SUM(InvNetAmount) AS NetAmount,
                                SUM(InvCustomerPayment) AS CustomerPayment,
                                SUM(InvCostAmount) AS CostAmount,
                                SUM(InvReturnPayment) AS ReturnAmount');
            $this->db->from('invoicehed');
            $this->db->where('DATE(InvDate) <=', $enddate);
            $this->db->where('DATE(InvDate) >=', $startdate);
            $this->db->where_in('InvLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(InvDate)');
            $this->db->order_by('InvDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(InvDate) As InvDate,SUM(InvDisAmount) AS DisAmount,
                                SUM(InvCashAmount) AS CashAmount,
                                SUM(InvCCardAmount) AS CCardAmount,
                                SUM(InvCreditAmount) AS CreditAmount,
                                SUM(InvGiftVAmount) AS GiftVAmount,
                                SUM(InvLoyaltyAmount) AS LoyaltyAmount,
                                SUM(InvStarPoints) AS StarPoints,
                                SUM(InvChequeAmount) As ChequeAmount,
                                SUM(InvAmount) AS InvAmount,
                                SUM(InvVatAmount) AS VatAmount,
                                SUM(InvNbtAmount) AS NbtAmount,
                                SUM(InvNetAmount) AS NetAmount,
                                SUM(InvCustomerPayment) AS CustomerPayment,
                                SUM(InvCostAmount) AS CostAmount,
                                SUM(InvReturnPayment) AS ReturnAmount');
            $this->db->from('invoicehed');
            $this->db->where('DATE(InvDate) <=', $enddate);
            $this->db->where('DATE(InvDate) >=', $startdate);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(InvDate)');
            $this->db->order_by('InvDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function gencashreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(InvDate) As InvDate,SUM(InvDisAmount) AS DisAmount,
                                SUM(InvCashAmount) AS CashAmount,
                                SUM(InvCCardAmount) AS CCardAmount,
                                SUM(InvCreditAmount) AS CreditAmount,
                                SUM(InvGiftVAmount) AS GiftVAmount,
                                SUM(InvLoyaltyAmount) AS LoyaltyAmount,
                                SUM(InvStarPoints) AS StarPoints,
                                SUM(InvChequeAmount) As ChequeAmount,
                                SUM(InvAmount) AS InvAmount,
                                SUM(InvVatAmount) AS VatAmount,
                                SUM(InvNbtAmount) AS NbtAmount,
                                SUM(InvNetAmount) AS NetAmount,
                                SUM(InvCustomerPayment) AS CustomerPayment,
                                SUM(InvCostAmount) AS CostAmount,
                                SUM(InvReturnPayment) AS ReturnAmount');
            $this->db->from('invoicehed');
            $this->db->where('DATE(InvDate) =', $enddate);
            // $this->db->where('DATE(InvDate) >=', $startdate);
            $this->db->where_in('InvLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(InvDate)');
            $this->db->order_by('InvDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(InvDate) As InvDate,SUM(InvDisAmount) AS DisAmount,
                                SUM(InvCashAmount) AS CashAmount,
                                SUM(InvCCardAmount) AS CCardAmount,
                                SUM(InvCreditAmount) AS CreditAmount,
                                SUM(InvGiftVAmount) AS GiftVAmount,
                                SUM(InvLoyaltyAmount) AS LoyaltyAmount,
                                SUM(InvStarPoints) AS StarPoints,
                                SUM(InvChequeAmount) As ChequeAmount,
                                SUM(InvAmount) AS InvAmount,
                                SUM(InvVatAmount) AS VatAmount,
                                SUM(InvNbtAmount) AS NbtAmount,
                                SUM(InvNetAmount) AS NetAmount,
                                SUM(InvCustomerPayment) AS CustomerPayment,
                                SUM(InvCostAmount) AS CostAmount,
                                SUM(InvReturnPayment) AS ReturnAmount');
            $this->db->from('invoicehed');
            $this->db->where('DATE(InvDate) =', $enddate);
            // $this->db->where('DATE(InvDate) >=', $startdate);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(InvDate)');
            $this->db->order_by('InvDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function genjobreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        // if (isset($location) && $location != '') {
        //     $this->db->select('DATE(JobInvoiceDate) As InvDate,SUM(JobTotalDiscount) AS DisAmount,
        //                         SUM(JobCashAmount)+ SUM(ThirdCashAmount) AS CashAmount,
        //                         SUM(JobCardAmount)+ SUM(ThirdCardAmount) AS CCardAmount,
        //                         SUM(JobCreditAmount)+ SUM(ThirdCreditAmount) AS CreditAmount,
        //                         SUM(JobChequeAmount)+ SUM(ThirdChequeAmount) As ChequeAmount,
        //                         SUM(JobCompanyAmount) AS CompanyAmount,
        //                         SUM(JobTotalAmount) AS InvAmount,
        //                         SUM(JobAdvance) AS AdvanceAmount,
        //                         SUM(JobNetAmount) AS NetAmount,
        //                         SUM(JobVatAmount) AS VatAmount,
        //                         SUM(JobNbtAmount) AS NbtAmount');
        //     $this->db->from('jobinvoicehed');
        //     $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
        //     $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
        //     $this->db->where_in('JobLocation', $locationAr);
        //     $this->db->where('IsCancel', 0);
        //     $this->db->group_by('DATE(JobInvoiceDate)');
        //     $this->db->order_by('JobInvoiceDate', 'DESC');
        //     // $this->db->limit(50);
        // } else {
        //     $this->db->select('DATE(JobInvoiceDate) As InvDate,SUM(JobTotalDiscount) AS DisAmount,
        //                         SUM(JobCashAmount)+ SUM(ThirdCashAmount) AS CashAmount,
        //                         SUM(JobCardAmount)+ SUM(ThirdCardAmount) AS CCardAmount,
        //                         SUM(JobCreditAmount)+ SUM(ThirdCreditAmount) AS CreditAmount,
        //                         SUM(JobChequeAmount)+ SUM(ThirdChequeAmount) As ChequeAmount,
        //                         SUM(JobCompanyAmount) AS CompanyAmount,
        //                         SUM(JobTotalAmount) AS InvAmount,
        //                         SUM(JobAdvance) AS AdvanceAmount,
        //                         SUM(JobNetAmount) AS NetAmount,
        //                         SUM(JobVatAmount) AS VatAmount,
        //                         SUM(JobNbtAmount) AS NbtAmount');
        //     $this->db->from('jobinvoicehed');
        //     $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
        //     $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
        //     $this->db->where('IsCancel', 0);
        //     $this->db->group_by('DATE(JobInvoiceDate)');
        //     $this->db->order_by('JobInvoiceDate', 'DESC');
        //     // $this->db->limit(50);
        // }
        if (isset($location) && $location != '') {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,(JobTotalDiscount) AS DisAmount,JobInvNo,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,
                                (JobCostAmount) AS CostAmount,customer.CusName,
                                customer.RespectSign,creditinvoicedetails.SettledAmount');
            $this->db->from('jobinvoicehed');
            $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');
            $this->db->join('creditinvoicedetails', 'creditinvoicedetails.InvoiceNo = jobinvoicehed.JobInvNo', 'left');
            $this->db->join('jobcardhed', 'jobcardhed.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('jobinvoicehed.IsCancel', 0);
            // if (isset($invtype) && $invtype != '') {
            //     $this->db->where('JobInvType', $invtype);
            // }

            // if (isset($salesperson) && $salesperson != '') {
            //     $this->db->where('jobcardhed.assignTo', $salesperson);
            // }

            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,(JobTotalDiscount) AS DisAmount,JobInvNo,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,
                                (JobCostAmount) AS CostAmount,customer.CusName,
                                customer.RespectSign,creditinvoicedetails.SettledAmount');
            $this->db->from('jobinvoicehed');
            $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');
            $this->db->join('creditinvoicedetails', 'creditinvoicedetails.InvoiceNo = jobinvoicehed.JobInvNo', 'left');
            $this->db->join('jobcardhed', 'jobcardhed.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('jobinvoicehed.IsCancel', 0);
            // if (isset($invtype) && $invtype != '') {
            //     $this->db->where('JobInvType', $invtype);
            // }

            // if (isset($salesperson) && $salesperson != '') {
            //     $this->db->where('jobcardhed.assignTo', $salesperson);
            // }

            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function genjobsumreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,JobInvNo,(JobTotalDiscount) AS DisAmount,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,JRegNo,JobCardNo,JobBankAmount');
            $this->db->from('jobinvoicehed');
            $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('IsCancel', 0);
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,JobInvNo,(JobTotalDiscount) AS DisAmount,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,JRegNo,JobCardNo,JobBankAmount');
            $this->db->from('jobinvoicehed');
            $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('IsCancel', 0);
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function loadjobcardsummery($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select("jobcardhed.*, 
            jobinvoicehed.JobNetAmount, 
            jobinvoicehed.JobInvoiceDate, 
            jobinvoicehed.JobEstimateNo,
            customer.CusName, 
            model.model, 
            vehicledetail.Make, 
            salespersons.RepName AS Emp,jobcardhed.IsCompelte AS iscom,
            make.make AS MA, model.model AS MO, job_status.status_name AS status_name");


            $this->db->from('jobcardhed');
            $this->db->join('jobinvoicehed', 'jobinvoicehed.JobCardNo = jobcardhed.JobCardNo', 'INNER');
            $this->db->join('job_status','job_status.status_id=jobcardhed.IsCompelte', 'INNER');
            $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');
            $this->db->join('vehicledetail', 'vehicledetail.RegNo = jobinvoicehed.JRegNo', 'INNER');
            $this->db->join('make', 'make.make_id = vehicledetail.Make', 'INNER');
            $this->db->join('model', 'model.model_id = vehicledetail.Model', 'INNER');
            $this->db->join('salespersons', 'salespersons.RepID = jobcardhed.Jlabour', 'INNER');
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
            $this->db->where_in('jobcardhed.JobLocation', $locationAr);
            $this->db->where('jobcardhed.IsCancel', 0);
         
            $this->db->order_by('jobcardhed.JobCardNo', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select("jobcardhed.*, 
            jobinvoicehed.JobNetAmount, 
            jobinvoicehed.JobInvoiceDate, 
            jobinvoicehed.JobEstimateNo,
            customer.CusName, 
            model.model, 
            vehicledetail.Make, 
            salespersons.RepName AS Emp,jobcardhed.IsCompelte AS iscom,
            make.make AS MA, model.model AS MO,job_status.status_name AS status_name");


            $this->db->from('jobcardhed');
            $this->db->join('jobinvoicehed', 'jobinvoicehed.JobCardNo = jobcardhed.JobCardNo', 'LEFT');
            $this->db->join('job_status','job_status.status_id=jobcardhed.IsCompelte', 'INNER');
            $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');
            $this->db->join('vehicledetail', 'vehicledetail.RegNo = jobinvoicehed.JRegNo', 'INNER');
            $this->db->join('make', 'make.make_id = vehicledetail.Make', 'INNER');
            $this->db->join('model', 'model.model_id = vehicledetail.Model', 'INNER');
            $this->db->join('salespersons', 'salespersons.RepID = jobcardhed.Jlabour', 'INNER');
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
            $this->db->where('jobcardhed.IsCancel', 0);
         
            $this->db->order_by('jobcardhed.JobCardNo', 'DESC');
        }
        return $this->db->get()->result();
    }

    public function loademployeeproductivity($startdate, $enddate, $emp) {
       
            $this->db->select("salespersons.*,main_jobflat_details.* ");
            $this->db->from('salespersons');
            $this->db->join('main_jobflat_details', 'main_jobflat_details.Emp_No = salespersons.RepId', 'INNER');
            
            $this->db->where('DATE(main_jobflat_details.Date) <=', $enddate);
            $this->db->where('DATE(main_jobflat_details.Date) >=', $startdate);
          
            $this->db->order_by('main_jobflat_details.Date', 'DESC');
            if (isset($emp) && $emp != '') {
                $this->db->where('main_jobflat_details.Emp_No', $emp);
            }
        return $this->db->get()->result();
    }

    public function loadejobcardproductivity($startdate, $enddate, $jobcardno) {
       
        $this->db->select("jobinvoicehed.JobInvNo,main_jobflat_details.*");
        $this->db->from('jobinvoicehed');
        $this->db->join('main_jobflat_details', 'main_jobflat_details.Job_Inv_No = jobinvoicehed.JobInvNo', 'INNER');
        // $this->db->where('main_jobflat_details.Job_Inv_No',$jobcardno);
        $this->db->where('DATE(main_jobflat_details.Date) <=', $enddate);
        $this->db->where('DATE(main_jobflat_details.Date) >=', $startdate);
      
        $this->db->order_by('main_jobflat_details.Date', 'DESC');

    return $this->db->get()->result();
}

    public function genjobdaysumreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,JobInvNo,(JobTotalDiscount) AS DisAmount,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,JRegNo,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(JobInvoiceDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('IsCancel', 0);
            $this->db->group_by('DATE(jobinvoicehed.JobCardNo)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(JobInvoiceDate) As InvDate,JobInvNo,(JobTotalDiscount) AS DisAmount,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,JRegNo,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(JobInvoiceDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('IsCancel', 0);
            $this->db->group_by('DATE(jobinvoicehed.JobCardNo)');
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function gensalesdaysumreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(SalesDate) As InvDate,SalesInvNo,(SalesTotalDiscount) AS DisAmount,
                                (SalesCashAmount) AS CashAmount,
                                (SalesCCardAmount) AS CCardAmount,
                                (SalesCreditAmount) AS CreditAmount,
                                (SalesChequeAmount) As ChequeAmount,
                                (SalesBankAmount) AS BankAmount,
                                (SalesInvAmount) AS InvAmount,
                                (SalesAdvancePayment) AS AdvanceAmount,
                                (SalesNetAmount) AS NetAmount,
                                (SalesVatAmount) AS VatAmount,
                                (SalesNbtAmount) AS NbtAmount');
            $this->db->from('salesinvoicehed');
            // $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(SalesDate) As InvDate,SalesInvNo,(SalesTotalDiscount) AS DisAmount,
                                (SalesCashAmount) AS CashAmount,
                                (SalesCCardAmount) AS CCardAmount,
                                (SalesCreditAmount) AS CreditAmount,
                                (SalesChequeAmount) As ChequeAmount,
                                (SalesBankAmount) AS BankAmount,
                                (SalesInvAmount) AS InvAmount,
                                (SalesAdvancePayment) AS AdvanceAmount,
                                (SalesNetAmount) AS NetAmount,
                                (SalesVatAmount) AS VatAmount,
                                (SalesNbtAmount) AS NbtAmount');
            $this->db->from('salesinvoicehed');
            // $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            // $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
        }
        return $this->db->get()->result();
    }

    public function genjobdaysalesumreportbypayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('jobinvoicehed.*,jobinvoicepaydtl.*,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('IsCancel', 0);
            $this->db->group_by('(jobinvoicehed.JobCardNo)');
            $this->db->order_by('JobInvDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('jobinvoicehed.*,jobinvoicepaydtl.*,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('IsCancel', 0);

             $this->db->group_by('(jobinvoicehed.JobCardNo)');
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function salesinvoicedaysalesumreportbypayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('salesinvoicehed.*,salesinvoicedtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicedtl', 'salesinvoicedtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
         
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            // $this->db->group_by('(jobinvoicehed.JobCardNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('salesinvoicehed.*,salesinvoicedtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicedtl', 'salesinvoicedtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
          
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('InvIsCancel', 0);

            // $this->db->group_by('(jobinvoicehed.JobCardNo)');
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function genjobmonthsalesumreportbypayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('jobinvoicehed.*,jobinvoicepaydtl.*,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvDate) <=', $enddate);
            $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('IsCancel', 0);
            $this->db->group_by('(jobinvoicehed.JobCardNo)');
            $this->db->order_by('JobInvDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('jobinvoicehed.*,jobinvoicepaydtl.*,jobcarddtl.JobDescription');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('IsCancel', 0);

            $this->db->group_by('(jobinvoicehed.JobCardNo)');
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function gensalesdaysalesumreportbypayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('salesinvoicehed.*,salesinvoicepaydtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('salesinvoicehed.*,salesinvoicepaydtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            // $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function gensalemonthsalesumreportbypayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('salesinvoicehed.*,salesinvoicepaydtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            $this->db->where('DATE(SalesDate) >=', $startdate);
            $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
             $this->db->select('salesinvoicehed.*,salesinvoicepaydtl.*');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            $this->db->where('DATE(SalesDate) >=', $startdate);
            // $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('(salesinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function genjobdaycashsumreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('JobInvPayAmount,JobCreditAmount');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
            $this->db->where('IsCancel', 0);
            $this->db->group_by('DATE(jobinvoicehed.JobCardNo)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('JobInvPayAmount,JobCreditAmount');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobinvoicepaydtl', 'jobinvoicepaydtl.JobInvNo = jobinvoicehed.JobInvNo', 'INNER');
            $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = jobinvoicehed.JobCardNo', 'INNER');
            $this->db->where('JobInvPayType =', 'Cash');
            $this->db->where('DATE(JobInvoiceDate) =', $enddate);
            // $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where('IsCancel', 0);

            $this->db->group_by('DATE(jobinvoicehed.JobCardNo)');
            // $this->db->group_by('DATE(JobInvoiceDate)');
            $this->db->order_by('JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }

    public function gensalesdaycashsumreportbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('SalesInvPayAmount,SalesCreditAmount');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = salesinvoicehed.JobCardNo', 'INNER');
            $this->db->where('SalesInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(jobinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('SalesInvPayAmount,SalesCreditAmount');
            $this->db->from('salesinvoicehed');
            $this->db->join('salesinvoicepaydtl', 'salesinvoicepaydtl.SalesInvNo = salesinvoicehed.SalesInvNo', 'INNER');
            // $this->db->join('jobcarddtl', 'jobcarddtl.JobCardNo = salesinvoicehed.JobCardNo', 'INNER');
            $this->db->where('SalesInvPayType =', 'Cash');
            $this->db->where('DATE(SalesDate) =', $enddate);
            // $this->db->where('DATE(JobInvDate) >=', $startdate);
            // $this->db->where_in('SalesLocation', $locationAr);
            $this->db->where('InvIsCancel', 0);
            $this->db->group_by('DATE(jobinvoicehed.SalesInvNo)');
            $this->db->order_by('SalesDate', 'DESC');
        }
        return $this->db->get()->result();
    }

    public function genjobreportbyproduct($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('JobCode,
                           jobinvoicehed.JobInvNo,
                           jobinvoicehed.JobInvoiceDate,
                           Prd_AppearName AS AppearName,
                           JobCost,
                           JobPrice,
                          (JobQty) AS Qty,
                          (JobCost * JobQty) AS CostValue,
                           (jobinvoicedtl.JobTotalAmount) AS TotalAmount,
                           (jobinvoicedtl.JobDiscount) AS DisAmount,
                           (jobinvoicedtl.JobNetAmount) AS NetAmount,
                           (jobinvoicehed.JobTotalDiscount) AS TotalDiscount,
                           department.Description,
                           product.DepCode,
                           product.SubCategoryCode');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = jobinvoicedtl.JobCode', 'INNER');
        $this->db->join('department', 'department.DepCode = product.DepCode', 'INNER');
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.InvLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('JobCode', $product);
        }
        
         if (isset($dep) && $dep != '' ) {
            $this->db->where('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
//        $this->db->group_by('invoicedtl.InvNo');
        $this->db->order_by('jobinvoicehed.JobInvoiceDate');
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }

    public function genjobreportbyservices($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('JobCode,
                           jobinvoicehed.JobInvNo,
                           jobinvoicehed.JobInvoiceDate,
                           JobDescription AS AppearName,
                           JobCost,
                           JobPrice,
                          (JobQty) AS Qty,
                          (JobCost * JobQty) AS CostValue,
                           (jobinvoicedtl.JobTotalAmount) AS TotalAmount,
                           (jobinvoicedtl.JobDiscount) AS DisAmount,
                           (jobinvoicedtl.JobVatAmount) AS VatAmount,
                           (jobinvoicedtl.JobNbtAmount) AS NbtAmount,
                           (jobinvoicedtl.JobNetAmount) AS NetAmount,
                           (jobinvoicehed.JobTotalDiscount) AS TotalDiscount,
                           jobtype.jobtype_name,
                           jobtype.jobtype_code,
                           jobtype.jobtype_order');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('jobtype', 'jobtype.jobtype_id = jobinvoicedtl.JobType', 'INNER');
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('jobinvoicedtl.JobType', $product);
        }
        
        //  if (isset($dep) && $dep != '' ) {
        //     $this->db->where('product.DepCode', $dep);
        // }
        
        // if (isset($subdep) && $subdep != '' ) {
        //     $this->db->where('product.SubDepCode', $subdep);
        // }
        
        // if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
        //     $this->db->where_in('product.SubCategoryCode', $subcat);
        // }
        
//        $this->db->group_by('invoicedtl.InvNo');
        $this->db->order_by('jobinvoicehed.JobInvNo');
        $this->db->order_by('jobtype.jobtype_order', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->jobtype_name][] = $row;
        }
        return $list;
    }


   public function loadAllWorkType($startdate, $enddate) {
        $this->db->select('
            DATE(jobinvoicehed.JobInvoiceDate) AS JobInvoiceDate,
            jobtype.jobtype_name,
            SUM(jobinvoicedtl.JobTotalAmount) AS TotalAmount
        ');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('jobtype', 'jobtype.jobtype_id = jobinvoicedtl.JobType', 'INNER');
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        $this->db->group_by(['DATE(jobinvoicehed.JobInvoiceDate)', 'jobtype.jobtype_name']);
        
        return $this->db->get()->result();
    }

    public function getAllJobTypes() {
        return $this->db
            ->select('jobtype_id, jobtype_name')
            ->from('jobtype')
            ->order_by('jobtype_name', 'ASC')
            ->get()
            ->result();
    }

    public function genjobreportbymake($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
         $this->db->select('(JobInvoiceDate) As InvDate,JobInvNo,jobinvoicehed.JobCardNo,(JobTotalDiscount) AS DisAmount,
                                (JobCashAmount)+ (ThirdCashAmount) AS CashAmount,
                                (JobCardAmount)+ (ThirdCardAmount) AS CCardAmount,
                                (JobCreditAmount)+ (ThirdCreditAmount) AS CreditAmount,
                                (JobChequeAmount)+ (ThirdChequeAmount) As ChequeAmount,
                                (JobCompanyAmount) AS CompanyAmount,
                                (JobTotalAmount) AS InvAmount,
                                (JobAdvance) AS AdvanceAmount,
                                (JobNetAmount) AS NetAmount,
                                (JobVatAmount) AS VatAmount,
                                (JobNbtAmount) AS NbtAmount,job_section.JobSection,make.make,jobinvoicehed.JRegNo,Count(JobInvNo) AS count');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobcardhed', 'jobinvoicehed.JobCardNo = jobcardhed.JobCardNo', 'INNER');
            $this->db->join('job_section', 'job_section.JobSecNo = jobcardhed.Jsection', 'INNER');
            $this->db->join('vehicledetail', 'jobinvoicehed.JRegNo = vehicledetail.RegNo', 'INNER');
            $this->db->join('make', 'make.make_id = vehicledetail.Make', 'INNER');
            $this->db->where('DATE(JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(JobInvoiceDate) >=', $startdate);
            $this->db->where_in('JobLocation', $locationAr);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('jobcardhed.Jsection', $product);
        }
        
         if (isset($dep) && $dep != '' ) {
            $this->db->where('vehicledetail.Make', $dep);
        }
        
        // if (isset($subdep) && $subdep != '' ) {
        //     $this->db->where('product.SubDepCode', $subdep);
        // }
        
        // if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
        //     $this->db->where_in('product.SubCategoryCode', $subcat);
        // }
        
       $this->db->group_by('jobinvoicehed.JobInvNo');
        $this->db->order_by('jobinvoicehed.JobInvNo');
        $this->db->order_by('job_section.JobSecNo', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->JobSection][$row->make][] = $row;
        }
        return $list;
    }

    public function genjobreportbyinvoices($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('JobCode,
                           jobinvoicehed.JobInvNo,
                           jobinvoicehed.JobInvoiceDate,
                           JobDescription AS AppearName,
                           JobCost,
                           JobPrice,
                           (JobQty) AS Qty,
                           (JobCost * JobQty) AS CostValue,
                           (jobinvoicedtl.JobTotalAmount) AS TotalAmount,
                           (jobinvoicedtl.JobDiscount) AS DisAmount,
                           (jobinvoicedtl.JobVatAmount) AS VatAmount,
                           (jobinvoicedtl.JobNbtAmount) AS NbtAmount,
                           (jobinvoicedtl.JobNetAmount) AS NetAmount,
                           (jobinvoicehed.JobTotalDiscount) AS TotalDiscount,
                           jobtype.jobtype_name,
                           jobtype.jobtype_code,
                           jobtype.jobtype_order');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('jobtype', 'jobtype.jobtype_id = jobinvoicedtl.JobType', 'INNER');
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('jobinvoicedtl.JobType', $product);
        }
        
        //  if (isset($dep) && $dep != '' ) {
        //     $this->db->where('product.DepCode', $dep);
        // }
        
        // if (isset($subdep) && $subdep != '' ) {
        //     $this->db->where('product.SubDepCode', $subdep);
        // }
        
        // if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
        //     $this->db->where_in('product.SubCategoryCode', $subcat);
        // }
        
//        $this->db->group_by('invoicedtl.InvNo');
        $this->db->order_by('jobinvoicehed.JobInvNo');
        $this->db->order_by('jobtype.jobtype_order', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->JobInvNo." | ".$row->JobInvoiceDate][] = $row;
        }
        return $list;
    }

    public function genpaymentreportbyinvoices($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('jobinvoicehed.JobInvNo,
                           jobinvoicehed.JobInvoiceDate,
                           jobinvoicehed.JobCardNo,
                           jobinvoicehed.JobNetAmount,
                           jobinvoicepaydtl.*,customer.CusName
                           ');
        $this->db->from('jobinvoicepaydtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicepaydtl.JobInvNo', 'INNER');
        $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');
        $this->db->where('DATE(jobinvoicepaydtl.JobInvDate) <=', $enddate);
        $this->db->where('DATE(jobinvoicepaydtl.JobInvDate) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('jobinvoicedtl.JobType', $product);
        }
        
        //  if (isset($dep) && $dep != '' ) {
        //     $this->db->where('product.DepCode', $dep);
        // }
        
        // if (isset($subdep) && $subdep != '' ) {
        //     $this->db->where('product.SubDepCode', $subdep);
        // }
        
        // if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
        //     $this->db->where_in('product.SubCategoryCode', $subcat);
        // }
        
        // $this->db->group_by('invoicedtl.InvNo');
        $this->db->order_by('jobinvoicehed.JobInvNo');
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->JobInvNo." | ".$row->JobInvoiceDate." | ".$row->JobCardNo." | ".$row->CusName." ------------ Total Invoice Amount - ".$row->JobNetAmount][] = $row;
        }
        return $list;
    }


    public function genjobreporttotalDiscountbyproduct($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('SUM(jobinvoicehed.JobTotalDiscount) AS TotalDiscount');
        $this->db->from('jobinvoicehed');
        $this->db->join('jobinvoicedtl', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = jobinvoicedtl.JobCode', 'INNER');
        $this->db->join('department', 'department.DepCode = product.DepCode', 'left');
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
        $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('JobCode', $product);
        }
        
        if (isset($dep) && $dep != '' ) {
            $this->db->where('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        $this->db->group_by('jobinvoicedtl.JobInvNo');
        //$this->db->group_by('ProductCode');
        // $this->db->limit(50);
        $result=$this->db->get();
        $list=0;
        foreach ($result->result() as $row) {
            $list += $row->TotalDiscount;
        }
        return $list;
    }

    public function genreportbyproduct($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('salesinvoicedtl.SalesProductCode,
                           salesinvoicehed.SalesInvNo,
                           salesinvoicehed.SalesDate,
                          salesinvoicedtl.SalesProductName AS SalesProductName,
                           	salesinvoicedtl.SalesUnitPrice,
                           salesinvoicedtl.SalesCostPrice,
                          (salesinvoicedtl.SalesQty) AS Qty,
                           (salesinvoicedtl.SalesFreeQty) AS FreeQty,
                          (salesinvoicedtl.SalesCostPrice * salesinvoicedtl.SalesQty) AS CostValue,
                           (salesinvoicedtl.SalesTotalAmount) AS TotalAmount,
                           (salesinvoicedtl.SalesDisValue) AS DisAmount,
                           (salesinvoicedtl.SalesInvNetAmount) AS NetAmount,
                           (salesinvoicedtl.SalesReturnQty) AS ReturnQty,
                           (salesinvoicehed.SalesDisAmount) AS TotalDiscount,
                           department.Description,
                           product.DepCode,
                           product.SubCategoryCode,
                (salesinvoicedtl.SalesSerialNo) AS Serial');
        $this->db->from('salesinvoicedtl');
        $this->db->join('salesinvoicehed', 'salesinvoicehed.SalesInvNo = salesinvoicedtl.SalesInvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = salesinvoicedtl.SalesProductCode', 'INNER');
        $this->db->join('department', 'department.DepCode = product.DepCode', 'INNER');
        // $this->db->where('DATE(salesinvoicehed.SalesDate) <=', $enddate);
        // $this->db->where('DATE(salesinvoicehed.SalesDate) >=', $startdate);
        // $this->db->where('salesinvoicehed.InvIsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('salesinvoicehed.SalesLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('InvProductCode', $product);
        }
        
         if (isset($dep) && $dep != '' ) {
            $this->db->where('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
//        $this->db->group_by('invoicedtl.InvNo');
        $this->db->order_by('salesinvoicehed.SalesDate');
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
       
        return $list;
    }

    public function gencashreportbyproduct($startdate, $enddate, $location = NULL, $locationAr = NULL) {
        $this->db->select('InvProductCode,
                           invoicehed.InvNo,invoicehed.InvCashAmount,invoicehed.InvChequeAmount,invoicehed.InvCreditAmount,invoicehed.InvCCardAmount,
                           DATE(invoicehed.InvDate) AS InvDate,
                           Prd_AppearName AS AppearName,
                           InvCostPrice,
                           InvUnitPrice,
                          (InvQty) AS Qty,
                           (InvFreeQty) AS FreeQty,
                          (InvCostPrice * InvQty) AS CostValue,
                           (invoicedtl.InvTotalAmount) AS TotalAmount,
                           (invoicedtl.InvDisValue) AS DisAmount,
                           (invoicehed.InvNetAmount) AS NetAmount,
                           (InvReturnQty) AS ReturnQty,
                           (invoicehed.InvDisAmount) AS TotalDiscount,
                           product.DepCode,
                           product.SubCategoryCode,
                (invoicedtl.InvSerialNo) AS Serial');
        $this->db->from('invoicedtl');
        $this->db->join('invoicehed', 'invoicehed.InvNo = invoicedtl.InvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = invoicedtl.InvProductCode', 'INNER');
        $this->db->where('DATE(invoicehed.InvDate) =', $enddate);
        // $this->db->where('DATE(invoicehed.InvDate) >=', $startdate);
        $this->db->where('invoicehed.InvIsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('invoicehed.InvLocation', $locationAr);
        }
        $this->db->group_by('invoicehed.InvDate');
        $this->db->order_by('invoicehed.InvDate');
        $result=$this->db->get()->result();
        return $result;
    }

    public function gencashmonthreportbyproduct($startdate, $enddate, $location = NULL, $locationAr = NULL) {
        $this->db->select('InvProductCode,
                           invoicehed.InvNo,invoicehed.InvCashAmount,invoicehed.InvChequeAmount,invoicehed.InvCreditAmount,invoicehed.InvCCardAmount,
                           DATE(invoicehed.InvDate) AS InvDate,
                           Prd_AppearName AS AppearName,
                           InvCostPrice,
                           InvUnitPrice,
                        (InvQty) AS Qty,
                        (InvFreeQty) AS FreeQty,
                        (InvCostPrice * InvQty) AS CostValue,
                           (invoicedtl.InvTotalAmount) AS TotalAmount,
                           (invoicedtl.InvDisValue) AS DisAmount,
                           (invoicehed.InvNetAmount) AS NetAmount,
                           (InvReturnQty) AS ReturnQty,
                           (invoicehed.InvDisAmount) AS TotalDiscount,
                           product.DepCode,
                           product.SubCategoryCode,
                (invoicedtl.InvSerialNo) AS Serial');
        $this->db->from('invoicedtl');
        $this->db->join('invoicehed', 'invoicehed.InvNo = invoicedtl.InvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = invoicedtl.InvProductCode', 'INNER');
        $this->db->where('DATE(invoicehed.InvDate) <=', $enddate);
        $this->db->where('DATE(invoicehed.InvDate) >=', $startdate);
        $this->db->where('invoicehed.InvIsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('invoicehed.InvLocation', $locationAr);
        }
        $this->db->group_by('invoicehed.InvDate');
        $this->db->order_by('invoicehed.InvDate');
        $result=$this->db->get()->result();
        return $result;
    }

    public function gencashreportbypart($startdate, $enddate, $location = NULL, $locationAr = NULL) {
        $this->db->select('SalesProductCode,
                           salesinvoicehed.SalesInvNo,salesinvoicehed.SalesCashAmount,salesinvoicehed.SalesChequeAmount,salesinvoicehed.SalesBankAmount,salesinvoicehed.SalesCreditAmount,salesinvoicehed.SalesCCardAmount,
                           DATE(salesinvoicehed.SalesDate) AS InvDate,
                           SalesProductName AS AppearName,
                           SalesCostPrice,SalesVehicle,
                           SalesUnitPrice,
                          (SalesQty) AS Qty,
                           (SalesFreeQty) AS FreeQty,
                          (SalesCostPrice * SalesQty) AS CostValue,
                           (salesinvoicedtl.SalesTotalAmount) AS TotalAmount,
                           (salesinvoicedtl.SalesDisValue) AS DisAmount,
                           (salesinvoicehed.SalesNetAmount) AS NetAmount,
                           (SalesReturnQty) AS ReturnQty,
                           (salesinvoicehed.SalesDisAmount) AS TotalDiscount,salesinvoicehed.InvIsCancel,
                (salesinvoicedtl.SalesSerialNo) AS Serial');
        $this->db->from('salesinvoicedtl');
        $this->db->join('salesinvoicehed', 'salesinvoicehed.SalesInvNo = salesinvoicedtl.SalesInvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = salesinvoicedtl.SalesProductCode', 'left');
        $this->db->where('DATE(salesinvoicehed.SalesDate) =', $enddate);
        // $this->db->where('DATE(invoicehed.InvDate) >=', $startdate);
        $this->db->where('salesinvoicehed.InvIsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('salesinvoicehed.SalesLocation', $locationAr);
        }
        $this->db->group_by('salesinvoicehed.SalesDate');
        $this->db->order_by('salesinvoicehed.SalesDate');
        $result=$this->db->get()->result();
        return $result;
    }
    
    public function genreporttotalDiscountbyproduct($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('SUM(salesinvoicehed.SalesDisAmount) AS TotalDiscount');
        $this->db->from('salesinvoicehed');
        $this->db->join('salesinvoicedtl', 'salesinvoicehed.SalesInvNo = salesinvoicedtl.SalesInvNo', 'INNER');
        $this->db->join('product', 'product.ProductCode = salesinvoicedtl.SalesProductCode', 'INNER');
        $this->db->join('department', 'department.DepCode = product.DepCode', 'left');
        $this->db->where('DATE(salesinvoicehed.SalesDate) <=', $enddate);
        $this->db->where('DATE(salesinvoicehed.SalesDate) >=', $startdate);
        $this->db->where('salesinvoicehed.InvIsCancel', 0);
        if (isset($location) && $location != '') {
            $this->db->where_in('salesinvoicehed.SalesLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('SalesProductCode', $product);
        }
        
        if (isset($dep) && $dep != '' ) {
            $this->db->where('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        $this->db->group_by('salesinvoicedtl.SalesInvNo');
        //$this->db->group_by('ProductCode');
        // $this->db->limit(50);
        $result=$this->db->get();
        $list=0;
        foreach ($result->result() as $row) {
            $list += $row->TotalDiscount;
        }
        return $list;
    }
    
    public function expensesbydate($route,$startdate, $enddate, $isExp = NULL) {
        $this->db->select('SUM(FlotAmount) AS FlotAmount');
        $this->db->from('cashflot');
        $this->db->join('transactiontypes', 'transactiontypes.TransactionCode = cashflot.TransactionCode', 'INNER');
        $this->db->where('DATE(cashflot.FlotDate) <=', $enddate);
        $this->db->where('DATE(cashflot.FlotDate) >=', $startdate);
        if (isset($route) && $route != '') {
            $this->db->where_in('cashflot.Location', $route);
        }
        
        $this->db->where('transactiontypes.IsExpenses', $isExp);
        $result=$this->db->get();
        
        $list=0;
        foreach ($result->result() as $row) {
            $list += $row->FlotAmount;
        }
        return $list;
    }
    
    public function searchproduct($q) {
        $this->db->select('ProductCode AS id,Prd_Description AS text');
        $this->db->from('product');
        $this->db->where('product.Prd_IsActive', 1);
        $this->db->like('CONCAT(ProductCode,Prd_Description)', $q, 'left');
        $this->db->limit(50);
        return $this->db->get()->result();
    }

     public function searchStockproduct($q) {
        
        $this->db->select('product.ProductCode AS id,product.Prd_Description AS text,productcondition.IsPromotions');
        $this->db->from('product');
        $this->db->join('productcondition', 'productcondition.ProductCode = product.ProductCode', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
        $this->db->where('productcondition.IsPromotions',0);
        $this->db->like('CONCAT(product.ProductCode,product.Prd_Description)', $q, 'left');
        $this->db->limit(50);
        return $this->db->get()->result();
    }
    
    public function searchsupplier($q) {
        $this->db->select('SupCode AS id,SupName AS text');
        $this->db->from('supplier');
        $this->db->like('CONCAT(SupCode,SupName)', $q, 'left');
        $this->db->where('IsActive',1);
        $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function searchjobcardjson($q) {
        $this->db->select('JobInvNo AS id,JobInvNo AS text');
        $this->db->from(' jobinvoicehed');
        $this->db->like('CONCAT(JobInvNo,JobInvNo)', $q, 'left');
        $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function searchsalesperson($q) {
        $this->db->select('RepID AS id,RepName AS text');
        $this->db->from('salespersons');
        $this->db->like('CONCAT(RepID,RepName)', $q, 'left');
        $this->db->limit(50);
        return $this->db->get()->result();
    }
    
    public function searchdepartment($q) {
        $this->db->select('DepCode AS id,Description AS text');
        $this->db->from('department');
        $this->db->like('CONCAT(DepCode,Description)', $q, 'left');
        $this->db->group_by('Description');
        $this->db->limit(50);
        return $this->db->get()->result();
    }
    
    public function searchsubdepartment($q,$cat) {
        $this->db->select('subdepartment.SubDepCode AS id,subdepartment.Description AS text');
        $this->db->from('subdepartment');
        $this->db->where('subdepartment.DepCode', $cat);
        $this->db->join('department', 'department.DepCode = subdepartment.DepCode', 'INNER');
        $this->db->like('CONCAT(subdepartment.SubDepCode,subdepartment.Description)', $q, 'left');
        $this->db->group_by('subdepartment.Description');
        $this->db->limit(50);
        return $this->db->get()->result();
    }
    
    public function searchsubcategory($q,$cat,$cat2) {
        $this->db->select('subcategory.SubCategoryCode AS id,subcategory.Description AS text');
        $this->db->from('subcategory');
        $this->db->where('subcategory.DepCode', $cat);
        $this->db->where('subcategory.SubDepCode', $cat2);
        $this->db->like('CONCAT(subcategory.SubCategoryCode,subcategory.Description)', $q);
        $this->db->group_by('subcategory.Description');
        $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function searchcustomer($q) {
        $this->db->select('customer.CusCode AS id,customer.CusName AS text');
                        $this->db->from('customer');
                        $this->db->where('IsActive',1);
                        $this->db->like("CONCAT(customer.CusCode,' ',customer.CusName)", $q);
                        $this->db->group_by('customer.CusName');
                        $this->db->limit(50);
                    
        return $this->db->get()->result();
    }

    public function searchvehicle($q) {
        $this->db->select('vehicledetail.RegNo AS id,vehicledetail.RegNo AS text');
                        $this->db->from('vehicledetail');
                        $this->db->like("CONCAT(vehicledetail.RegNo)", $q);
                        $this->db->group_by('vehicledetail.VehicleId');
                        $this->db->limit(50);
                    
        return $this->db->get()->result();
    }

    public function searchmake($q) {
        $this->db->select('make.make_id AS id,make.make AS text');
                        $this->db->from('make');
                        $this->db->like("CONCAT(make.make)", $q);
                        $this->db->group_by('make.make_id');
                        $this->db->limit(50);
                    
        return $this->db->get()->result();
    }


    public function productdetail($route, $isall, $product = NULL,$dep,$subdep,$sup,$subcat) {
        $this->db->select('product.ProductCode,
                           product.Prd_Description,
                           product.Prd_CostPrice,
                           product.SubDepCode,
                           product.Prd_ROL,
                           product.Prd_ROQ,
                           subdepartment.Description,
                           location.location,
                           productstock.Stock,
                           productprice.ProductPrice,
                           supplier.SupName,productcondition.IsPromotions');
        $this->db->from('product');
        $this->db->join('supplier', 'supplier.SupCode = product.Prd_Supplier', 'LEFT');
         $this->db->join('productcondition', 'productcondition.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('productstock', 'productstock.ProductCode = product.ProductCode', 'LEFT');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
        $this->db->join('productprice', 'productprice.ProductCode = product.ProductCode', 'LEFT');
        $this->db->join('subcategory', 'subcategory.SubCategoryCode = product.SubCategoryCode', 'left');
        $this->db->join('location', 'location.location_id = productstock.Location', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
          $this->db->where('productcondition.IsPromotions', 0);
        if (isset($route) && $route != '') {
            $this->db->where_in('productstock.Location', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where_in('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where_in('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
//        $this->db->order_by('product.SubCategoryCode', 'ASC');
        $this->db->order_by('subcategory.Description', 'ASC');
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }
    
    public function lowproductdetail($route, $isall, $product = NULL,$dep,$subdep,$sup,$subcat) {
        $this->db->select('product.ProductCode,
                            product.Prd_Description,
                            product.Prd_CostPrice,
                            product.SubDepCode,
                             product.Prd_ROL,
                              product.Prd_ROQ,
                            subdepartment.Description,
                            location.location,
                            productstock.Stock,
                            supplier.SupName,productcondition.IsPromotions');
        $this->db->from('product');
          $this->db->join('productcondition', 'productcondition.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('supplier', 'supplier.SupCode = product.Prd_Supplier', 'INNER');
        $this->db->join('productstock', 'productstock.ProductCode = product.ProductCode', 'LEFT');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
        $this->db->join('subcategory', 'subcategory.SubCategoryCode = product.SubCategoryCode', 'INNER');
        $this->db->join('location', 'location.location_id = productstock.Location', 'INNER');
        $this->db->where('productstock.Stock < product.Prd_ROL');
        $this->db->where('product.Prd_IsActive', 1);
         $this->db->where('productcondition.IsPromotions', 0);
        if (isset($route) && $route != '') {
            $this->db->where_in('productstock.Location', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where_in('product.DepCode', $dep);
        }
        
        if (isset($dep) && $dep != '' && isset($subdep) && $subdep != '' ) {
            $this->db->where_in('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        $this->db->order_by('product.SubCategoryCode', 'ASC');
//        $this->db->order_by('subcategory.Description', 'ASC');
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }

    public function priceproductdetail($route, $isall, $product = NULL,$dep,$subdep,$sup) {
        $this->db->select('product.ProductCode,
                            product.Prd_Description,
                            product.SubDepCode,
                            subdepartment.Description,
                            product.Prd_CostPrice,
                            location.location,
                            pricestock.Stock,
                            pricestock.Price,
                            supplier.SupName,productcondition.IsPromotions');
        $this->db->from('product');
        $this->db->join('supplier', 'supplier.SupCode = product.Prd_Supplier', 'INNER');
          $this->db->join('productcondition', 'productcondition.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('pricestock', 'pricestock.PSCode = product.ProductCode', 'LEFT');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
//        $this->db->join('subcategory', 'subcategory.SubCategoryCode = product.SubCategoryCode', 'INNER');
        $this->db->join('location', 'location.location_id = pricestock.PSLocation', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
         $this->db->where('productcondition.IsPromotions', 0);
        if (isset($route) && $route != '') {
            $this->db->where('pricestock.PSLocation', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where('product.DepCode', $dep);
        }
        
        if (isset($dep) && $dep != '' && isset($subdep) && $subdep != '' ) {
            $this->db->where('product.SubDepCode', $subdep);
        }
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        $this->db->order_by('product.SubCategoryCode', 'ASC');
//        $this->db->order_by('subcategory.Description', 'ASC');
        $result= $this->db->get();
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }

    public function productdetailserial($route, $isall, $product = NULL,$dep,$subdep,$sup,$subcat) {
        $this->db->select('product.ProductCode,
                            product.Prd_Description,
                            product.Prd_CostPrice AS Prd_CostPrice,
                            location.location,
                            productserialstock.Quantity,
                            productserialstock.SerialNo,
                            supplier.SupName,
                            subdepartment.Description,
                            goodsreceivenotehed.GRN_DateORG');
        $this->db->from('product');
        $this->db->join('productserialstock', 'productserialstock.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
        $this->db->join('location', 'location.location_id = productserialstock.Location', 'INNER');
        $this->db->join('goodsreceivenotehed', 'goodsreceivenotehed.GRN_No = productserialstock.GrnNo', 'Left');
        $this->db->join('goodsreceivenotedtl', 'goodsreceivenotehed.GRN_No = goodsreceivenotedtl.GRN_No', 'INNER');
        $this->db->join('supplier', 'supplier.SupCode = goodsreceivenotehed.GRN_SupCode', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
        
        if (isset($isall) && $isall == 'all') {
        }elseif (isset($isall) && $isall == '1') {
            $this->db->where('productserialstock.Quantity', $isall);
        }elseif (isset($isall) && $isall == '0') {
            $this->db->where('productserialstock.Quantity', $isall);
        }
        
        if (isset($route) && $route != '' && count($route)>0) {
            $this->db->where_in('productserialstock.Location', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where_in('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where_in('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->group_by('productserialstock.SerialNo');
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        $this->db->order_by('product.SubCategoryCode', 'ASC');
//        $this->db->order_by('subcategory.Description', 'ASC');
        
        $result=$this->db->get();
        
        
        $this->db->select('product.ProductCode,
                            product.Prd_Description,
                            stocktransferdtl.CostPrice AS Prd_CostPrice,
                            location.location,
                            productserialstock.Quantity,
                            productserialstock.SerialNo,
                            supplier.SupName,
                            subdepartment.Description,
                            stocktransferhed.TransDateORG As GRN_DateORG');
        $this->db->from('product');
        $this->db->join('productserialstock', 'productserialstock.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
        $this->db->join('location', 'location.location_id = productserialstock.Location', 'INNER');
        $this->db->join('stocktransferhed', 'stocktransferhed.TrnsNo = productserialstock.GrnNo', 'Left');
        $this->db->join('stocktransferdtl', 'stocktransferhed.TrnsNo = stocktransferdtl.TrnsNo', 'INNER');
        $this->db->join('supplier', 'supplier.SupCode = product.Prd_Supplier', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
        
        if (isset($isall) && $isall == 'all') {
        }elseif (isset($isall) && $isall == '1') {
            $this->db->where('productserialstock.Quantity', $isall);
        }elseif (isset($isall) && $isall == '0') {
            $this->db->where('productserialstock.Quantity', $isall);
        }
        
        if (isset($route) && $route != '' && count($route)>0) {
            $this->db->where_in('productserialstock.Location', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where_in('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where_in('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->group_by('productserialstock.SerialNo');
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        $this->db->order_by('product.SubCategoryCode', 'ASC');
//        $this->db->order_by('subcategory.Description', 'ASC');
        
        $result2=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        foreach ($result2->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }
    
    
    public function productdetailserial2($route, $isall, $product = NULL,$dep,$subdep,$sup,$subcat) {
        $this->db->select('product.ProductCode,
                            product.Prd_Description,
                            stocktransferdtl.CostPrice AS Prd_CostPrice,
                            location.location,
                            productserialstock.Quantity,
                            productserialstock.SerialNo,
                            supplier.SupName,
                            subdepartment.Description,
                            stocktransferhed.GRN_DateORG');
        $this->db->from('product');
        $this->db->join('productserialstock', 'productserialstock.ProductCode = product.ProductCode', 'INNER');
        $this->db->join('subdepartment', 'subdepartment.SubDepCode = product.SubDepCode', 'INNER');
        $this->db->join('location', 'location.location_id = productserialstock.Location', 'INNER');
        $this->db->join('stocktransferhed', 'stocktransferhed.TrnsNo = productserialstock.GrnNo', 'Left');
        $this->db->join('stocktransferdtl', 'stocktransferhed.TrnsNo = stocktransferdtl.TrnsNo', 'INNER');
        $this->db->join('supplier', 'supplier.SupCode = product.Prd_Supplier', 'INNER');
        $this->db->where('product.Prd_IsActive', 1);
        
        if (isset($isall) && $isall == 'all') {
        }elseif (isset($isall) && $isall == '1') {
            $this->db->where('productserialstock.Quantity', $isall);
        }elseif (isset($isall) && $isall == '0') {
            $this->db->where('productserialstock.Quantity', $isall);
        }
        
        if (isset($route) && $route != '' && count($route)>0) {
            $this->db->where_in('productserialstock.Location', $route);
        }
        if (isset($product) && $product != '' && $isall == 0) {
            $this->db->where('product.ProductCode', $product);
        }
        if (isset($dep) && $dep != '' ) {
            $this->db->where_in('product.DepCode', $dep);
        }
        
        if (isset($subdep) && $subdep != '' ) {
            $this->db->where_in('product.SubDepCode', $subdep);
        }
        
        if ( isset($subcat) && $subcat != '' && count($subcat) != 0) {
            $this->db->where_in('product.SubCategoryCode', $subcat);
        }
        
        if (isset($sup) && $sup != '') {
            $this->db->where('product.Prd_Supplier', $sup);
        }
        $this->db->group_by('productserialstock.SerialNo');
        $this->db->order_by('product.DepCode', 'ASC');
        $this->db->order_by('product.SubDepCode', 'ASC');
        $this->db->order_by('product.CategoryCode', 'ASC');
        $this->db->order_by('product.SubCategoryCode', 'ASC');
//        $this->db->order_by('subcategory.Description', 'ASC');
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->Description][] = $row;
        }
        return $list;
    }
    
    // public function cashfloatbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        
    //         $this->db->select('*,users.first_name,cashinout.Remark As Remark');
    //         $this->db->from('cashinout');
    //          $this->db->join('transactiontypes', 'transactiontypes.TransactionCode = cashinout.TransCode', 'INNER');
    //         $this->db->join('users', 'users.id = cashinout.SystemUser', 'INNER');
    //         $this->db->where('DATE(cashinout.InOutDate) <=', $enddate);
    //         $this->db->where('DATE(cashinout.InOutDate) >=', $startdate);
    //         $this->db->where_in('cashinout.Location', $locationAr);
    //         // $this->db->limit(50);
        
    //     return $this->db->get()->result();
    // }

    public function cashfloatbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL,$tCode = NULL,$tCode_ar = NULL) {
        //        var_dump($startdate);die();
                    $this->db->select('*,users.first_name,cashinout.Remark As Remark');
                    $this->db->from('cashinout');
                    $this->db->join('transactiontypes', 'transactiontypes.TransactionCode = cashinout.TransCode', 'INNER');
                    $this->db->join('users', 'users.id = cashinout.SystemUser', 'INNER');
                    $this->db->where('DATE(cashinout.InOutDate) <=', $enddate);
                    $this->db->where('DATE(cashinout.InOutDate) >=', $startdate);
                    $this->db->where_in('cashinout.Location', $locationAr);
                if (isset($tCode_ar) && $tCode_ar != '') {
                    $this->db->where_in('transactiontypes.TransactionCode', $tCode_ar);
                }
                    // $this->db->limit(50);
        
                $result=$this->db->get();
        
                $list = array();
                foreach ($result->result() as $row) {
                    $list[$row->TransactionName	][] = $row;
                }
                return $list;
        
        
        //        return $this->db->get()->result();
            }
    public function cashfloatbytype($startdate, $enddate, $location = NULL,$locationAr = NULL,$type,$emp) {
        
        $this->db->select('cashflot.*,transactiontypes.IsExpenses,users.first_name,cashflot.Remark As Remark');
        $this->db->from('cashflot');
        $this->db->join('transactiontypes', 'transactiontypes.TransactionCode = cashflot.TransactionCode', 'INNER');
        $this->db->join('users', 'users.id = cashflot.SystemUser', 'INNER');
        $this->db->where('DATE(DateORG) <=', $enddate);
        $this->db->where('DATE(DateORG) >=', $startdate);
        $this->db->where('cashflot.TransactionCode!=', $type);
        if (isset($emp) && $emp != '') {
            $this->db->where('Emp', $emp);
        }
        $this->db->where_in('cashflot.Location', $locationAr);
        // $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function cashfloatsalarybytype($startdate, $enddate, $location = NULL,$locationAr = NULL,$type,$emp,$exp) {
        
        $this->db->select('cashflot.*,users.first_name,cashflot.Remark As Remark');
        $this->db->from('cashflot');
        $this->db->join('transactiontypes', 'transactiontypes.TransactionCode = cashflot.TransactionCode', 'INNER');
        $this->db->join('users', 'users.id = cashflot.SystemUser', 'INNER');
        $this->db->where('DATE(DateORG) <=', $enddate);
        $this->db->where('DATE(DateORG) >=', $startdate);
        $this->db->where('cashflot.TransactionCode', $type);
        if (isset($emp) && $emp != '') {
            $this->db->where('cashflot.Emp', $emp);
        }

        if (isset($exp) && $exp != '') {
            $this->db->where('transactiontypes.IsExpenses', $exp);
        }

        $this->db->where_in('cashflot.Location', $locationAr);
        // $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function totalsupplierpayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        
        $this->db->select('CashPay,CardPay');
        $this->db->from('supplierpaymenthed');
        $this->db->where('DATE(PayDate) =', $enddate);
        if (isset($location) && $location != '') {
           $this->db->where_in('supplierpaymenthed.Location', $locationAr);
        }
        
        return $this->db->get()->result();
    }

    public function totalmonthsupplierpayment($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        
        $this->db->select('CashPay,CardPay');
        $this->db->from('supplierpaymenthed');
        $this->db->where('DATE(PayDate) <=', $enddate);
        $this->db->where('DATE(PayDate) >=', $startdate);
        if (isset($location) && $location != '') {
           $this->db->where_in('supplierpaymenthed.Location', $locationAr);
        }
        
        return $this->db->get()->result();
    }

    public function totalcuspayment($startdate, $enddate, $location = NULL,$locationAr = NULL,$type) {
        
        $this->db->select('CashPay,CardPay');
        $this->db->from('customerpaymenthed');
        $this->db->where('DATE(PayDate) =', $enddate);
        $this->db->where('PaymentType', $type);
        $this->db->where('IsCancel', 0);
        
        if (isset($location) && $location != '') {
           $this->db->where_in('customerpaymenthed.Location', $locationAr);
        }
        
        return $this->db->get()->result();
    }

    public function totalcuspaymentsummary($startdate, $enddate, $location = NULL,$locationAr = NULL,$type) {
        
        $this->db->select('customerpaymenthed.*,customer.CusName');
        $this->db->from('customerpaymenthed');
         $this->db->join('customer', 'customer.CusCode = customerpaymenthed.CusCode', 'INNER');
        $this->db->where('DATE(PayDate) =', $enddate);
        $this->db->where('PaymentType', $type);
        $this->db->where('IsCancel', 0);
        
        if (isset($location) && $location != '') {
           $this->db->where_in('customerpaymenthed.Location', $locationAr);
        }
        
        return $this->db->get()->result();
    }

    public function totalcusmonthpaymentsummary($startdate, $enddate, $location = NULL,$locationAr = NULL,$type) {
        
        $this->db->select('customerpaymenthed.*,customer.CusName');
        $this->db->from('customerpaymenthed');
         $this->db->join('customer', 'customer.CusCode = customerpaymenthed.CusCode', 'INNER');
        $this->db->where('DATE(PayDate) <=', $enddate);
        $this->db->where('DATE(PayDate) >=', $startdate);
        $this->db->where('PaymentType', $type);
        $this->db->where('IsCancel', 0);
        
        if (isset($location) && $location != '') {
           $this->db->where_in('customerpaymenthed.Location', $locationAr);
        }
        
        return $this->db->get()->result();
    }


    
    public function cashinoutbyroute($startdate, $enddate, $location = NULL,$locationAr = NULL,$emp,$type) {
        
            $this->db->select('cashinout.*,users.first_name');
            $this->db->from('cashinout');
            $this->db->join('users', 'users.id = cashinout.SystemUser', 'INNER');
            $this->db->where('DATE(InOutDate) <=', $enddate);
            $this->db->where('DATE(InOutDate) >=', $startdate);
            $this->db->where_in('cashinout.Location', $locationAr);
            if (isset($emp) && $emp != '') {
               $this->db->where('cashinout.Emp', $emp);
            }

            if (isset($type) && $type != '') {
               $this->db->where('cashinout.TransCode', $type);
            }
            // $this->db->limit(50);
        
        return $this->db->get()->result();
    }

    public function cashinoutsalarybytype($startdate, $enddate, $location = NULL,$locationAr = NULL, $type) {
        
            $this->db->select('cashinout.*,users.first_name');
            $this->db->from('cashinout');
            $this->db->join('users', 'users.id = cashinout.SystemUser', 'INNER');
            $this->db->where('DATE(InOutDate) =', $enddate);
            // $this->db->where('DATE(InOutDate) >=', $startdate);
            // $this->db->where('Emp!=', 0);
            $this->db->where('TransCode', $type);
            $this->db->where('Mode=', 'Out');
            $this->db->where_in('cashinout.Location', $locationAr);
            // $this->db->limit(50);
        
        return $this->db->get()->result();
    }

    public function cashinoutmonthsalarybytype($startdate, $enddate, $location = NULL,$locationAr = NULL, $type) {
        
            $this->db->select('cashinout.*,users.first_name');
            $this->db->from('cashinout');
            $this->db->join('users', 'users.id = cashinout.SystemUser', 'INNER');
            $this->db->where('DATE(InOutDate) <=', $enddate);
            $this->db->where('DATE(InOutDate) >=', $startdate);
            // $this->db->where('Emp!=', 0);
            $this->db->where('TransCode', $type);
            $this->db->where('Mode=', 'Out');
            $this->db->where_in('cashinout.Location', $locationAr);
            // $this->db->limit(50);
        
        return $this->db->get()->result();
    }

    public function cashinoutbyroutebytype($startdate, $enddate, $location = NULL,$locationAr = NULL, $type) {
        
            $this->db->select('cashinout.*,users.first_name,transactiontypes.TransactionName,salespersons.RepName,');
            $this->db->from('cashinout');
            $this->db->join('users', 'users.id = cashinout.SystemUser', 'left');
            $this->db->join('salespersons','cashinout.Emp=salespersons.RepID','left');
            $this->db->join('transactiontypes','cashinout.TransCode=transactiontypes.TransactionCode','left');
            $this->db->where('DATE(cashinout.InOutDate) =', $enddate);
            // $this->db->where('DATE(InOutDate) >=', $startdate);
            $this->db->where('TransCode!=', $type);
            $this->db->where_in('cashinout.Location', $locationAr);
            $this->db->where('cashinout.IsActive',1);
            // $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function cashinoutmonthbyroutebytype($startdate, $enddate, $location = NULL,$locationAr = NULL, $type) {
        
            $this->db->select('cashinout.*,users.first_name,transactiontypes.TransactionName,salespersons.RepName');
            $this->db->from('cashinout');
            $this->db->join('users', 'users.id = cashinout.SystemUser', 'left');
            $this->db->join('salespersons','cashinout.Emp=salespersons.RepID','left');
            $this->db->join('transactiontypes','cashinout.TransCode=transactiontypes.TransactionCode','left');
            $this->db->where('DATE(InOutDate) <=', $enddate);
            $this->db->where('DATE(InOutDate) >=', $startdate);
            $this->db->where('TransCode!=', $type);
            $this->db->where_in('cashinout.Location', $locationAr);
            // $this->db->limit(50);
        return $this->db->get()->result();
    }

    public function productdailyfinalstock($startdate, $enddate, $route, $product = NULL,$dep,$subdep,$subcat) {
        $query = $this->db->query("CALL SPR_STOCK_FINAL_V2('$startdate','$enddate','$route','$product','$dep','$subdep','$subcat')");
        $result = array();
        foreach ($query->result() as $rows) {
        $result[$rows->CategoryName][] = $rows;
        }
        return $result;
    }
    
     public function productdailyfinalstock2($startdate, $enddate, $route, $product = NULL) {
        $query = $this->db->query("CALL SPR_STOCK_FINAL('$startdate','$enddate','$route','$product')");
//        $result = array();
        $data = array(); 
while($row = $query->result()) { 
  $data[$row['country']][$row['city']] = $row['venue']; 
} 
foreach($row as $country => $cities) { 
  echo "<h1>$country</h1>\n"; 
  foreach($cities as $city => $venues) { 
    echo "<h2>$city</h2>\n"; 
    
  } 
}  
//        foreach ($query->result() as $rows) {
//            $result[] = $rows;
//        }
//        return $result;
    }

    public function laststockreportdate() {
        if (isset($this->db->select_max('StockDate')->from('stockdate')->get()->row()->StockDate) &&
                $this->db->select_max('StockDate')->from('stockdate')->get()->row()->StockDate != '') {
            return $this->db->select_max('StockDate')->from('stockdate')->get()->row()->StockDate;
        } else {
            return date("Y-m-d");
        }
    }

    public function dailyreportupdate($date, $user) {
        $now = date("Y-m-d H:i:s");
        if ($this->db->query("CALL SPT_UPDATE_DAILY_STOCK('$date','$user','$now')")) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function dailyreportupdateuserdata() {
        $maxid = $this->db->select_max('id')->from('stockdateuser')->get()->row()->id;
        return $this->db->select()->from('stockdateuser')->where('id', $maxid)->get()->row();
    }

    public function suppliercredit($startdate, $enddate, $route = NULL,$isall,$customer) {
        
        $this->db->select('creditgrndetails.SupCode,
                    DATE(creditgrndetails.GRNDate) AS InvoiceDate,
                    creditgrndetails.GRNNo,
                    creditgrndetails.NetAmount,
                    creditgrndetails.CreditAmount,
                    creditgrndetails.SettledAmount,
                    supplier.SupName,
                    title.TitleName,
                    supplier.Address01,
                    supplier.Address02,
                    supplier.Address03,
                    goodsreceivenotehed.GRN_No');
        $this->db->from('creditgrndetails');
        $this->db->join('goodsreceivenotehed','creditgrndetails.GRNNo=goodsreceivenotehed.GRN_No','left');
        $this->db->join('supplier','creditgrndetails.SupCode = supplier.SupCode');
        $this->db->join('title','title.TitleId = supplier.SupTitle');
        $this->db->where('creditgrndetails.CreditAmount > creditgrndetails.SettledAmount');
        $this->db->where('creditgrndetails.IsCancel',0);
        if (isset($isall) && $isall == 0 ) {
            if (isset($enddate) && $enddate != '' ) {
            $this->db->where('DATE(creditgrndetails.GRNDate) <=', $enddate);
            }
            if (isset($startdate) && $startdate != '' ) {
            $this->db->where('DATE(creditgrndetails.GRNDate) >=', $startdate);
            }
        }
        if (isset($route) && $route != '' ) {
            $this->db->where('creditgrndetails.Location',$route);
        }
        if (isset($customer) && $customer != '' ) {
            $this->db->where('creditgrndetails.SupCode',$customer);
        }
        $this->db->order_by('creditgrndetails.SupCode,creditgrndetails.GRNDate');
        $result= $this->db->get();

        $list = array();
        foreach ($result->result() as $row) {
            $list[$row->TitleName." ".$row->SupName][] = $row;
        }
        return $list;
    }

    public function customercredit($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customer.MobileNo,creditinvoicedetails.CusCode,
                            DATE(creditinvoicedetails.InvoiceDate) AS InvoiceDate,
                            creditinvoicedetails.InvoiceNo,
                            creditinvoicedetails.NetAmount,
                            creditinvoicedetails.CreditAmount,
                            creditinvoicedetails.SettledAmount,
                            SUM(creditinvoicedetails.returnAmount) AS ReturnAmount,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            salespersons.RepName,
                            customer.Address02,
                            jobinvoicehed.JobCardNo,
                            jobinvoicehed.JRegNo');
                $this->db->from('creditinvoicedetails');
                $this->db->join('jobinvoicehed','creditinvoicedetails.InvoiceNo=jobinvoicehed.JobInvNo','left');
                $this->db->join('customer','creditinvoicedetails.CusCode = customer.CusCode');
                $this->db->join('salespersons','salespersons.RepID = customer.HandelBy','left');
                // $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('creditinvoicedetails.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('creditinvoicedetails.Location',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('creditinvoicedetails.CusCode',$customer);
                  }
                 // $this->db->where('creditinvoicedetails.CreditAmount !=creditinvoicedetails.SettledAmount'); 
                  $this->db->group_by('creditinvoicedetails.InvoiceDate');
                  $this->db->order_by('creditinvoicedetails.InvoiceDate');
                   
              return $this->db->get()->result();
    }

    public function customercreditstatement($startdate, $enddate, $loc = NULL,$isall,$customer) {
        
            $this->db->select('customer.MobileNo,creditinvoicedetails.CusCode,
                            DATE(creditinvoicedetails.InvoiceDate) AS InvoiceDate,
                            creditinvoicedetails.InvoiceNo,
                            creditinvoicedetails.NetAmount,
                            creditinvoicedetails.CreditAmount,
                            creditinvoicedetails.SettledAmount,
                            creditinvoicedetails.returnAmount,
                            SUM(creditinvoicedetails.returnAmount) AS returnAmounts,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            jobinvoicehed.JobCardNo,
                            jobinvoicehed.JRegNo');
                $this->db->from('creditinvoicedetails');
                $this->db->join('jobinvoicehed','creditinvoicedetails.InvoiceNo=jobinvoicehed.JobInvNo','left');
                $this->db->join('customer','creditinvoicedetails.CusCode = customer.CusCode');
                // $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('creditinvoicedetails.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) >=', $startdate);
                }
            }
                 if (isset($loc) && $loc != '' ) {
                // $this->db->where('creditinvoicedetails.Location',$loc);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('creditinvoicedetails.CusCode',$customer);
                  }
                 // $this->db->where('creditinvoicedetails.CreditAmount !=creditinvoicedetails.SettledAmount');
                  $this->db->group_by('creditinvoicedetails.InvoiceNo');
                  $this->db->order_by('creditinvoicedetails.InvoiceDate');

              return $this->db->get()->result();
    }

    public function loadsuppliercreditoutstanding($startdate, $enddate, $loc = NULL, $supCode) {
        $this->db->select('creditgrndetails.*');
        $this->db->from('creditgrndetails');
        $this->db->where('creditgrndetails.SupCode', $supCode);
        $this->db->where('creditgrndetails.IsCloseGRN', 0);
        $this->db ->where('creditgrndetails.IsCancel', 0);  
        return $this->db->get()->result();
    }

    public function loadsuppliercredisummury($startdate, $enddate, $loc = NULL, $supCode) {
        $isall = isset($_POST['isall']) ? 1 : 0;
    
        $this->db->select('creditgrndetails.SupCode, 
            SUM(creditgrndetails.CreditAmount) AS TotalCredit, 
            SUM(creditgrndetails.SettledAmount) AS TotalSettledAmount, 
            SUM(creditgrndetails.NetAmount) AS TotalDue, 
            supplier.SupName, 
            supplier.MobileNo'
        );
        $this->db->from('creditgrndetails');
        $this->db->join('supplier', 'supplier.SupCode = creditgrndetails.SupCode', 'left');
        $this->db->where('creditgrndetails.IsCloseGRN', 0);
        $this->db->where('creditgrndetails.IsCancel', 0);
        $this->db->where('supplier.IsActive', 1);
        if ($isall == 1) {
       
            $this->db->group_by('creditgrndetails.SupCode');
            $this->db->order_by('supplier.SupName', 'ASC');
            return $this->db->get()->result(); 
        } else {
            $this->db->where('creditgrndetails.SupCode', $supCode);
            return $this->db->get()->result(); 
        }
    }
    

    public function loadsupplier($startdate, $enddate, $loc = NULL, $supCode) {
        $this->db->select('supplier.SupName,supplier.MobileNo');
        $this->db->from('supplier');
        $this->db->where('SupCode',$supCode);
        return $this->db->get()->result();
    }
    
    public function customerpayment($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customerpaymenthed.CusPayNo,
                            customerpaymenthed.CusCode,
                            customerpaymenthed.TotalPayment,
                            customerpaymentdtl.`Mode`,
                            customerpaymentdtl.PayAmount,
                            customerpaymentdtl.BankNo,
                            customerpaymentdtl.ChequeNo,
                            DATE(customerpaymentdtl.ChequeDate) AS ChequeDate,
                            DATE(customerpaymentdtl.RecievedDate) AS RecievedDate,
                            customerpaymentdtl.Reference,
                            customerpaymenthed.PayDate,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            bank.BankName');
                $this->db->from('customerpaymenthed');
                $this->db->join('customerpaymentdtl','customerpaymentdtl.CusPayNo=customerpaymenthed.CusPayNo');
                $this->db->join('customer','customerpaymenthed.CusCode = customer.CusCode');
                $this->db->join('bank','customerpaymentdtl.BankNo = bank.BankCode','left');
                 $this->db->where('customerpaymenthed.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(customerpaymenthed.PayDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(customerpaymenthed.PayDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('customerpaymenthed.Location',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('customerpaymenthed.CusCode',$customer);
                  }
                   
              return $this->db->get()->result();
    }

    public function customercreditbyvehicle($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('creditinvoicedetails.CusCode,
                            DATE(creditinvoicedetails.InvoiceDate) AS InvoiceDate,
                            creditinvoicedetails.InvoiceNo,
                            creditinvoicedetails.NetAmount,
                            creditinvoicedetails.CreditAmount,
                            creditinvoicedetails.SettledAmount,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            jobinvoicehed.JobCardNo,
                            jobinvoicehed.JRegNo');
                $this->db->from('creditinvoicedetails');
                $this->db->join('jobinvoicehed','creditinvoicedetails.InvoiceNo=jobinvoicehed.JobInvNo','left');
                $this->db->join('customer','creditinvoicedetails.CusCode = customer.CusCode');
                $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('creditinvoicedetails.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('creditinvoicedetails.Location',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('creditinvoicedetails.CusCode',$customer);
                  }
                   
              return $this->db->get()->result();
    }

    public function customerpaymentbyvehicle($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customerpaymenthed.CusPayNo,
                            customerpaymenthed.CusCode,
                            customerpaymenthed.TotalPayment,
                            customerpaymentdtl.`Mode`,
                            customerpaymentdtl.PayAmount,
                            customerpaymentdtl.BankNo,
                            customerpaymentdtl.ChequeNo,
                            DATE(customerpaymentdtl.ChequeDate) AS ChequeDate,
                            DATE(customerpaymentdtl.RecievedDate) AS RecievedDate,
                            customerpaymentdtl.Reference,
                            customerpaymenthed.PayDate,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            bank.BankName');
                $this->db->from('customerpaymenthed');
                $this->db->join('customerpaymentdtl','customerpaymentdtl.CusPayNo=customerpaymenthed.CusPayNo');
                $this->db->join('customer','customerpaymenthed.CusCode = customer.CusCode');
                $this->db->join('bank','customerpaymentdtl.BankNo = bank.BankCode','left');
                 $this->db->where('customerpaymenthed.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(customerpaymenthed.PayDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(customerpaymenthed.PayDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('customerpaymenthed.Location',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('customerpaymenthed.CusCode',$customer);
                  }
                   
              return $this->db->get()->result();
    }

    public function invoicesbyvehicle($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('JobCode,
                           jobinvoicehed.JobInvNo,
                           DATE(jobinvoicehed.JobInvoiceDate) AS JobInvoiceDate,
                           JobDescription AS AppearName,
                           JobCost,
                           JobPrice,
                          (JobQty) AS Qty,
                          (JobCost * JobQty) AS CostValue,
                           (jobinvoicedtl.JobTotalAmount) AS TotalAmount,
                           (jobinvoicedtl.JobDiscount) AS DisAmount,
                           (jobinvoicedtl.JobNetAmount) AS NetAmount,
                           (jobinvoicehed.JobTotalDiscount) AS TotalDiscount,
                           jobtype.jobtype_name,
                           jobtype.jobtype_code,
                           jobtype.jobtype_order,
                           customer.CusName,
                           jobinvoicehed.JobCardNo,
                           jobinvoicehed.JRegNo');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobinvoicehed', 'jobinvoicehed.JobInvNo = jobinvoicedtl.JobInvNo', 'INNER');
        $this->db->join('jobtype', 'jobtype.jobtype_id = jobinvoicedtl.JobType', 'INNER');
        $this->db->join('customer', 'customer.CusCode = jobinvoicehed.JCustomer', 'INNER');

        if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
               $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                 $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
                }
            }

        $this->db->where('jobinvoicehed.IsCancel', 0);
        if (isset($route) && $route != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $route);
        }
        if (isset($customer) && $customer != '') {
            $this->db->where('jobinvoicehed.JRegNo', $customer);
        }
        
        $this->db->order_by('jobinvoicehed.JobInvNo');
        $this->db->order_by('jobinvoicehed.JobInvoiceDate');
        $this->db->order_by('jobtype.jobtype_order', 'ASC');
        // $this->db->limit(50);
        
        
        $result=$this->db->get();
        
        $list = array();
        foreach ($result->result() as $row) {
        $list["Invoice No: " . $row->JobInvNo . " &nbsp; | &nbsp; Job Card No: " . $row->JobCardNo . " &nbsp;| &nbsp;Customer : " . $row->CusName . " |&nbsp; Vehicle No: " . $row->JRegNo][] = $row;
        }
        return $list;
    }

    public function jobdelivery($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            jobcardhed.JobCardNo,
                            jobcardhed.JRegNo,deliveryDate,appoimnetDate,status_name');
                $this->db->from('jobcardhed');
                $this->db->join('customer','jobcardhed.JCustomer = customer.CusCode');
                $this->db->join('job_status','job_status.status_id = jobcardhed.IsCompelte');
                $this->db->where('DATE(jobcardhed.deliveryDate) <',$enddate);
                 $this->db->where('jobcardhed.IsCancel',0);
            // if (isset($isall) && $isall == 0 ) {
            //     if (isset($enddate) && $enddate != '' ) {
            //     $this->db->where('DATE(jobcardhed.appoimnetDate) <=', $enddate);
            //     }
            //     if (isset($startdate) && $startdate != '' ) {
            //     $this->db->where('DATE(jobcardhed.appoimnetDate) >=', $startdate);
            //     }
            // }
                 if (isset($route) && $route != '' ) {
                $this->db->where('jobcardhed.JLocation',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('jobcardhed.JCustomer',$customer);
                  }
                   
              return $this->db->get()->result();
    }


    ///////////////////////////////////////////////////////////////////////////////////////

    public function customercreditsummary($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customer.MobileNo,creditinvoicedetails.CusCode,
                            DATE(creditinvoicedetails.InvoiceDate) AS InvoiceDate,
                            creditinvoicedetails.InvoiceNo,
                            SUM(creditinvoicedetails.NetAmount) AS NetAmount,
                            SUM(creditinvoicedetails.CreditAmount) AS CreditAmount,
                            SUM(creditinvoicedetails.SettledAmount) AS SettledAmount,
                            SUM(creditinvoicedetails.returnAmount) AS ReturnAmount,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            jobinvoicehed.JobCardNo,
                            jobinvoicehed.JRegNo,
                            salespersons.RepName');
                $this->db->from('creditinvoicedetails');
                $this->db->join('jobinvoicehed','creditinvoicedetails.InvoiceNo=jobinvoicehed.JobInvNo','left');
                $this->db->join('customer','creditinvoicedetails.CusCode = customer.CusCode');
                $this->db->join('salespersons','salespersons.RepID=customer.HandelBy','left');
                // $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('creditinvoicedetails.IsCancel',0);
//                 $this->db->where('creditinvoicedetails.Type!=',2);
                if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(creditinvoicedetails.InvoiceDate) >=', $startdate);
                }
                }
                 if (isset($route) && $route != '' ) {
                $this->db->where('creditinvoicedetails.Location',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('creditinvoicedetails.CusCode',$customer);
                  } 
//                $this->db->where('creditinvoicedetails.CreditAmount !=creditinvoicedetails.SettledAmount');
                $this->db->group_by('creditinvoicedetails.CusCode');
                $this->db->order_by('customer.CusName', 'ASC');
                
              return $this->db->get()->result();
    }

    public function customerjobcommission($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customer.MobileNo,
                            DATE(jobinvoicehed.JobInvoiceDate) AS InvoiceDate,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            jobinvoicehed.JobInvNo AS InvoiceNo,
                            jobinvoicehed.JobCommsion  AS commission');
                $this->db->from('jobinvoicehed');
                $this->db->join('customer','jobinvoicehed.JobComCus = customer.CusCode');
                // $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('jobinvoicehed.IsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('jobinvoicehed.JobLocation',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('jobinvoicehed.JobComCus',$customer);
                  }
                 // $this->db->where('creditinvoicedetails.CreditAmount !=creditinvoicedetails.SettledAmount'); 
                  $this->db->order_by('jobinvoicehed.JobInvoiceDate');
                   
              return $this->db->get()->result();
    }

    public function customersalecommission($startdate, $enddate, $route = NULL,$isall,$customer) {
        
            $this->db->select('customer.MobileNo,
                            DATE(salesinvoicehed.SalesDate) AS InvoiceDate,
                            customer.CusName,
                            customer.RespectSign,
                            customer.Address01,
                            customer.Address02,
                            salesinvoicehed.SalesInvNo AS InvoiceNo,
                            salesinvoicehed.SalesCommsion AS commission');
                $this->db->from('salesinvoicehed');
                $this->db->join('customer','salesinvoicehed.SalesComCus = customer.CusCode');
                // $this->db->where('creditinvoicedetails.CreditAmount > creditinvoicedetails.SettledAmount');
                 $this->db->where('salesinvoicehed.InvIsCancel',0);
            if (isset($isall) && $isall == 0 ) {
                if (isset($enddate) && $enddate != '' ) {
                $this->db->where('DATE(salesinvoicehed.SalesDate) <=', $enddate);
                }
                if (isset($startdate) && $startdate != '' ) {
                $this->db->where('DATE(salesinvoicehed.SalesDate) >=', $startdate);
                }
            }
                 if (isset($route) && $route != '' ) {
                $this->db->where('salesinvoicehed.SalesLocation',$route);
                 }
                  if (isset($customer) && $customer != '' ) {
                $this->db->where('salesinvoicehed.SalesComCus',$customer);
                  }
                 // $this->db->where('creditinvoicedetails.CreditAmount !=creditinvoicedetails.SettledAmount'); 
                  $this->db->order_by('salesinvoicehed.SalesDate');
                   
              return $this->db->get()->result();
    }
    
    public function genemployeewisejobsale($startdate, $enddate, $location = NULL,$locationAr = NULL) {
        if (isset($location) && $location != '') {
            $this->db->select('DATE(jobinvoicehed.JobInvoiceDate) As InvDate,jobinvoicehed.JobInvNo,SUM(jobinvoicehed.JobTotalDiscount) AS DisAmount,
                                SUM(jobinvoicehed.JobCashAmount)+ SUM(jobinvoicehed.ThirdCashAmount) AS CashAmount,
                                SUM(jobinvoicehed.JobCardAmount)+ SUM(jobinvoicehed.ThirdCardAmount) AS CCardAmount,
                                SUM(jobinvoicehed.JobCreditAmount)+ SUM(jobinvoicehed.ThirdCreditAmount) AS CreditAmount,
                                SUM(jobinvoicehed.JobChequeAmount)+ SUM(jobinvoicehed.ThirdChequeAmount) As ChequeAmount,
                                SUM(jobinvoicehed.JobCompanyAmount) AS CompanyAmount,
                                SUM(jobinvoicehed.JobTotalAmount) AS InvAmount,
                                SUM(jobinvoicehed.JobAdvance) AS AdvanceAmount,
                                SUM(jobinvoicehed.JobNetAmount) AS NetAmount,
                                SUM(jobinvoicehed.JobVatAmount) AS VatAmount,
                                SUM(jobinvoicehed.JobNbtAmount) AS NbtAmount,jobinvoicehed.JRegNo,jobcardhed.Jlabour,salespersons.RepName');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobcardhed','jobinvoicehed.JobCardNo = jobcardhed.JobCardNo','INNER');
            $this->db->join('salespersons','jobcardhed.Jlabour = salespersons.RepID','LEFT');
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
            $this->db->where('jobinvoicehed.IsCancel', 0);
            $this->db->group_by('jobcardhed.Jlabour');
            $this->db->order_by('jobinvoicehed.JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        } else {
            $this->db->select('DATE(jobinvoicehed.JobInvoiceDate) As InvDate,jobinvoicehed.JobInvNo,SUM(jobinvoicehed.JobTotalDiscount) AS DisAmount,
                                SUM(jobinvoicehed.JobCashAmount)+ SUM(jobinvoicehed.ThirdCashAmount) AS CashAmount,
                                SUM(jobinvoicehed.JobCardAmount)+ SUM(jobinvoicehed.ThirdCardAmount) AS CCardAmount,
                                SUM(jobinvoicehed.JobCreditAmount)+ SUM(jobinvoicehed.ThirdCreditAmount) AS CreditAmount,
                                SUM(jobinvoicehed.JobChequeAmount)+ SUM(jobinvoicehed.ThirdChequeAmount) As ChequeAmount,
                                SUM(jobinvoicehed.JobCompanyAmount) AS CompanyAmount,
                                SUM(jobinvoicehed.JobTotalAmount) AS InvAmount,
                                SUM(jobinvoicehed.JobAdvance) AS AdvanceAmount,
                                SUM(jobinvoicehed.JobNetAmount) AS NetAmount,
                                SUM(jobinvoicehed.JobVatAmount) AS VatAmount,
                                SUM(jobinvoicehed.JobNbtAmount) AS NbtAmount,jobinvoicehed.JRegNo,jobcardhed.Jlabour,salespersons.RepName');
            $this->db->from('jobinvoicehed');
            $this->db->join('jobcardhed','jobinvoicehed.JobCardNo = jobcardhed.JobCardNo','INNER');
            $this->db->join('salespersons','jobcardhed.Jlabour = salespersons.RepID','LEFT');
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) <=', $enddate);
            $this->db->where('DATE(jobinvoicehed.JobInvoiceDate) >=', $startdate);
            $this->db->where('jobinvoicehed.IsCancel', 0);
            $this->db->group_by('jobcardhed.Jlabour');
            $this->db->order_by('jobinvoicehed.JobInvoiceDate', 'DESC');
            // $this->db->limit(50);
        }
        return $this->db->get()->result();
    }
    
    public function genjobreportbyservicesbyjobtype($startdate, $enddate, $location = NULL, $product = NULL,$locationAr = NULL,$dep,$subdep,$subcat) {
        $this->db->select('jobinvoicedtl.JobDescription AS AppearName,
                           jobinvoicedtl.JobCost,
                           jobinvoicedtl.JobPrice,
                          SUM(jobinvoicedtl.JobQty) AS Qty,
                          SUM(jobinvoicedtl.JobCost * jobinvoicedtl.JobQty) AS CostValue,
                           SUM(jobinvoicedtl.JobTotalAmount) AS TotalAmount,
                           SUM(jobinvoicedtl.JobDiscount) AS DisAmount,
                           SUM(jobinvoicedtl.JobVatAmount) AS VatAmount,
                           SUM(jobinvoicedtl.JobNbtAmount) AS NbtAmount,
                           SUM(jobinvoicedtl.JobNetAmount) AS NetAmount,
                           (jobinvoicehed.JobTotalDiscount) AS TotalDiscount,salespersons.RepName');
        $this->db->from('jobinvoicedtl');
        $this->db->join('jobcardhed','jobinvoicedtl.JobCardNo = jobcardhed.JobCardNo','INNER');
        $this->db->join('salespersons','jobcardhed.Jlabour = salespersons.RepID','LEFT');
        $this->db->join('jobinvoicehed','jobinvoicedtl.JobInvNo = jobinvoicehed.JobInvNo','INNER');
//        $this->db->join('jobtype', 'jobtype.jobtype_id = jobinvoicedtl.JobType', 'INNER');
        $this->db->where('DATE(jobinvoicedtl.JobinvoiceTimestamp) <=', $enddate);
        $this->db->where('DATE(jobinvoicedtl.JobinvoiceTimestamp) >=', $startdate);
        $this->db->where('jobinvoicehed.IsCancel', 0);
        $this->db->where_not_in('jobinvoicedtl.JobType', array('9','3'));
        if (isset($location) && $location != '') {
            $this->db->where_in('jobinvoicehed.JobLocation', $locationAr);
        }
        if (isset($product) && $product != '') {
            $this->db->where('jobinvoicedtl.JobType', $product);
        }

        // $this->db->group_by('jobinvoicedtl.jobtype');
        $this->db->group_by('jobcardhed.Jlabour');
//        $this->db->order_by('jobinvoicedtl.JobCardNo');
//        $this->db->order_by('jobtype.jobtype_order', 'ASC');



        $result=$this->db->get()->result();

//        $list = array();
//        foreach ($result->result() as $row) {
//            $list[$row->jobtype_name][] = $row;
//        }
//        return $list;
        return $result;
    }



}
